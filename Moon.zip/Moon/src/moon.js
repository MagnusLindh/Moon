(function(){

//The canvas
var canvas = document.querySelector("canvas"); 
var drawingSurface = canvas.getContext("2d");

//Game Level Maps
//Arrays to store the level maps
var levelMaps = [];
var levelGameObjects = [];
var map = [];
var gameObjects = [];
var ROWS = 0;
var COLUMNS = 0;

//Gravity
var G=0.2;	
	
//A level counter
var levelCounter = 0;

//A timer to help delay the change time between levels
var levelChangeTimer = 0;
	
//A squash counter
var squashCounter=0;
	
//The small game map
var map0 = 
[
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],		
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,2,2,2,2,1,1,1,2,2,2,1,1,1],
	[1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1],
	[1,1,1,2,1,1,1,4,4,4,1,1,2,1,1,1],
	[1,1,1,2,1,1,5,5,5,5,4,1,1,1,1,1],
	[1,1,1,2,1,1,5,6,6,5,4,3,1,1,1,1],
	[1,1,1,2,1,1,5,6,6,5,4,3,1,1,1,1],
	[1,1,1,2,1,1,5,5,5,5,4,1,1,1,1,1],
	[1,1,1,2,1,1,1,4,4,4,1,1,2,1,1,1],
	[1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1],
	[1,1,1,2,2,2,1,1,1,1,1,2,2,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
];

//Push map0 into the leveMaps array
levelMaps.push(map0);		
		
//The small game objects map

var gameObjects0 =
[
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0],		
  [0,0,0,0,0,9,0,0,0,0,8,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
];

//Push gameObjects0 into the levelGameObjects array
levelGameObjects.push(gameObjects0);	
	
//The BIG game map 
var map1 =
[
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,1,1,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1],	
	[1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,2,1,1,4,4,4,4,4,1,4,4,4,4,4,4,1,1,2,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,2,1,1,4,4,4,4,4,1,4,4,4,4,4,4,1,1,2,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,2,1,1,4,1,1,1,1,1,5,5,5,5,4,4,1,1,2,2,1,1,1,1,1,1],	
	[1,1,1,1,1,1,2,2,1,1,4,1,1,1,1,1,5,5,5,5,4,1,1,1,2,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,1,1,1,4,1,1,5,6,6,6,6,5,5,1,1,1,1,2,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,1,1,1,1,1,1,5,6,6,6,6,5,5,1,1,1,3,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,1,1,3,1,1,1,5,6,6,6,6,5,5,1,1,1,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,2,1,1,3,1,1,1,5,6,6,6,6,5,5,4,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,3,1,1,1,5,5,5,5,5,5,5,4,4,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,5,5,5,5,5,5,5,4,4,3,1,1,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,3,3,1,1,1,1,4,4,4,4,4,4,4,4,3,1,1,2,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,3,3,1,1,1,1,1,4,4,4,4,4,4,4,3,1,1,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,2,3,3,1,1,1,1,1,1,3,3,3,3,3,3,3,1,1,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,2,3,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1],	
	[1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,1,1,1,1,2,2,2,2,2,2,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
];	
	
//Push map0 into the leveMaps array
levelMaps.push(map1);	
	
//The BIG game objects map

var gameObjects1 =
[
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,9,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,7,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
];
	
//Push gameObjects0 into the levelGameObjects array
levelGameObjects.push(gameObjects1);	

//The HUGE game map 
var map2 =
[
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
		
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,1,1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,2,2,2,2,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
		
	[1,1,1,1,1,1,1,1,1,2,2,2,3,3,3,3,3,3,3,3,3,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,3,3,3,3,3,3,3,3,1,3,3,3,3,1,1,3,3,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,3,3,1,3,3,1,1,2,2,2,1,1,1,1,1,1,1,1,1],		
	[1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,3,3,1,1,1,1,4,4,4,4,4,4,4,4,4,1,1,1,1,4,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
		
	[1,1,1,1,1,1,1,1,1,2,2,2,3,3,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,1,1,4,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,3,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,5,1,1,4,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,1,1,4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1],		
	[1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,4,1,1,1,6,6,6,6,6,6,1,1,1,1,4,1,1,1,3,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,1,1,4,1,1,1,6,6,6,6,6,6,1,1,1,1,4,1,1,1,3,2,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,3,1,1,1,1,1,1,1,6,6,6,6,6,6,1,1,1,1,4,1,1,1,3,2,2,2,1,1,1,1,1,1,1,1,1],
		
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,1,4,1,1,1,1,6,6,6,6,6,6,1,1,1,1,1,1,1,1,3,2,2,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,4,1,1,1,1,6,6,6,6,6,6,1,1,1,4,1,1,1,3,3,2,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,1,4,1,1,1,1,6,6,6,6,6,6,1,1,1,4,1,1,1,3,3,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4,1,1,1,3,1,1,1,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,4,1,1,1,1,1,1,5,5,5,1,1,1,1,1,1,1,1,1,3,1,1,1,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,4,1,1,1,1,1,1,1,1,1,1,5,5,5,1,1,1,1,1,3,1,1,2,2,1,1,1,1,1,1,1,1,1],
		
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,3,1,1,1,1,4,4,4,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1,3,3,3,1,1,1,1,1,1,1,1,1,3,1,1,1,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,3,3,3,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,3,3,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1],
		
	[1,1,1,1,1,1,1,1,1,2,2,2,1,2,2,2,1,2,2,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,1,2,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,2,2,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],	
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
		
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
];
	
//Push map2 into the leveMaps array
levelMaps.push(map2);	
	
//The HUGE game objects map

var gameObjects2 =
[
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],	
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
		
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,0,0,9,0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],

	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],	
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
		
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],

	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],	
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
		
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],

	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],	
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
		
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
];
	
//Push gameObjects0 into the levelGameObjects array
levelGameObjects.push(gameObjects2);	
	
//Map code
var EMPTY = 0;
var BOX = 4;
var HEDGEHOG = 7;
var CAT = 8;
var CRYSTAL = 9;
var DOOR = 10;

//The size of each tile cell
var SIZE = 32;

//Sprites we need to access by name
var cat = null;
var door = null;
//var gameOverDisplay = null;
var gameMessage = null;

//The number of columns on the tilesheet
var tilesheetColumns = 10;

//Arrays to store the game objects
var sprites = [];
var hedgehogs = [];
var boxes = [];
var messages = [];
var crystals = [];

var assetsToLoad = [];
var assetsLoaded = 0;

//Load the tilesheet image
var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "../images/tilemap.png";
assetsToLoad.push(image);

//Load the sounds	
var jumpSound = document.querySelector("#jumpSound");
jumpSound.addEventListener("canplaythrough", loadHandler, false);
jumpSound.load();
assetsToLoad.push(jumpSound);	
	
var levelUpSound = document.querySelector("#levelUpSound");
levelUpSound.addEventListener("canplaythrough", loadHandler, false);
levelUpSound.load();
assetsToLoad.push(levelUpSound);
	
var deadSound = document.querySelector("#deadSound");
deadSound.addEventListener("canplaythrough", loadHandler, false);
deadSound.load();
assetsToLoad.push(deadSound);
	
var crystalSound = document.querySelector("#crystalSound");
crystalSound.addEventListener("canplaythrough", loadHandler, false);
crystalSound.load();
assetsToLoad.push(crystalSound);
	
var squashSound = document.querySelector("#squashSound");
squashSound.addEventListener("canplaythrough", loadHandler, false);
squashSound.load();
assetsToLoad.push(squashSound);
	
var landSound = document.querySelector("#landSound");
landSound.addEventListener("canplaythrough", loadHandler, false);
landSound.load();
assetsToLoad.push(landSound);	
	
var doneSound = document.querySelector("#doneSound");
doneSound.addEventListener("canplaythrough", loadHandler, false);
doneSound.load();
assetsToLoad.push(doneSound);	
	
//Game variables
var crystalsCollected = 0;

//Game states
var LOADING = 0;
var BUILD_MAP = 1;
var PLAYING = 2;
var OVER = 3;
var LEVEL_COMPLETE = 4;
var RESTART = 5;
var gameState = LOADING;

//--- The gameWorld object
var gameWorld = 
{
  x: 0,
  y: 0,
  width: levelMaps[levelCounter][0].length * SIZE,
  height: levelMaps[levelCounter].length * SIZE,
};

//--- The camera object
var camera = 
{
  x: 0,
  y: 0,
  width: canvas.width,
  height: canvas.height,
  
  //The camera's inner scroll boundaries
  rightInnerBoundary: function()
  {
    return this.x + (this.width / 2) + (this.width / 4);
  },
  leftInnerBoundary: function()
  {
    return this.x + (this.width / 2) - (this.width / 4);
  },
  topInnerBoundary: function()
  {
    return this.y + (this.height / 2) - (this.height / 4);
  },
  bottomInnerBoundary: function()
  {
    return this.y + (this.height / 2) + (this.height / 4);
  }
};

//Center the camera over the gameWorld
camera.x = (gameWorld.x + gameWorld.width / 2) - camera.width / 2;
camera.y = (gameWorld.y + gameWorld.height / 2) - camera.height / 2;	
	
//Key codes
var RIGHT = 39;
var LEFT = 37;
var UP = 38;
var DOWN = 40;
var RKEY = 82;

//Directions
var moveRight = false;
var moveLeft = false;
var moveUp = false;
var moveDown = false;
var keyPressed = false;
	
//Gravity variables
var dx=0;
var dy=0;
var mx=gameWorld.width/2;
var my=gameWorld.height/2;
	
//Add keyboard listeners
window.addEventListener("keydown", function(event)
{
  switch(event.keyCode)
  {   
    case LEFT:
      moveLeft = true;
      keyPressed=true;
      break;  
	    
    case RIGHT:
      moveRight = true;
	  keyPressed=true;
      break; 
	  
    case UP:
      moveUp = true;
	  keyPressed=true;
      break;
	  
    case DOWN:
      moveDown = true;
	  keyPressed=true;
      break;
		
	case RKEY:
	  gameState = RESTART;
	  break;
  }

  event.preventDefault();
}, false);

window.addEventListener("keyup", function(event)
{
  switch(event.keyCode)
  {   
    case LEFT:
      moveLeft = false;
      break;  
	    
    case RIGHT:
      moveRight = false;
      break; 
	    
    case UP:
      moveUp = false;
      break;
	  
    case DOWN:
      moveDown = false;
      break; 
  }
}, false);

//Start the game animation loop
update();

function update()
{ 
  //The animation loop
  requestAnimationFrame(update, canvas);
  
  //Change what the game is doing based on the game state
  switch(gameState)
  {
    case LOADING:
      console.log("loading...");
      break;
      
    case BUILD_MAP:
	  map=arrayClone(levelMaps[levelCounter]);
	  gameObjects=arrayClone(levelGameObjects[levelCounter]);
	  mx=gameWorld.width/2;
	  my=gameWorld.height/2;
	  ROWS = map.length;
	  COLUMNS = map[0].length;
      buildMap(map);
      buildMap(gameObjects);
	  gameWorld.width = ROWS * SIZE;
	  gameWorld.height = COLUMNS * SIZE;	
      createOtherObjects();
      gameState = PLAYING;
      break;
    
    case PLAYING:
      playGame();
      break;
      
    case LEVEL_COMPLETE:
      levelComplete();
      break;
    
	case RESTART:
  	  levelCounter--;
	  gameState=LEVEL_COMPLETE;
  	  break;
		  
    case OVER:
      endGame();
  }
  
  //Render the game
  render();
}

function levelComplete()
{
	
  //Make the gameMessage visible
  gameMessage.text = "Ready?";
  gameMessage.visible = true;
  
  //Update the timer that changes the level by one
  levelChangeTimer++;
  
  //Load the next level after 60 frames
  if(levelChangeTimer === 60)
  {
    loadNextLevel();
  }
  
  function loadNextLevel()
  {  
	//Make the gameMessage invisible
  	gameMessage.visible = false;
	  
    //Reset the timer that changes the level
    levelChangeTimer = 0;
		
	//Update the levelCounter by 1
    levelCounter++;
  
    //Load the next level if there is one or end the game if there isn't
    if(levelCounter < levelMaps.length)
    {
      //Clear the objects    
	  sprites = [];
	  hedgehogs = [];
	  boxes = [];
	  crystals = [];
	  crystalsCollected=0;
	    
	  //Make sure the gameWorld size matches the size of the next level
      gameWorld.width = levelMaps[levelCounter][0].length * SIZE;
      gameWorld.height = levelMaps[levelCounter].length * SIZE;
	    
      //Re-center the camera
      camera.x = (gameWorld.x + gameWorld.width / 2) - camera.width / 2;
      camera.y = (gameWorld.y + gameWorld.height / 2) - camera.height / 2;
	    
      //Build the maps for the next level
      gameState = BUILD_MAP;
    }
    else
    {
      gameState = OVER;
    }
  }
}

function loadHandler()
{ 
  assetsLoaded++;
  if(assetsLoaded === assetsToLoad.length)
  {
    //Remove the load handlers
    image.removeEventListener("load", loadHandler, false);
	jumpSound.removeEventListener("canplaythrough", loadHandler, false);
	levelUpSound.removeEventListener("canplaythrough", loadHandler, false);
	deadSound.removeEventListener("canplaythrough", loadHandler, false);
	crystalSound.removeEventListener("canplaythrough", loadHandler, false);
	squashSound.removeEventListener("canplaythrough", loadHandler, false);
	landSound.removeEventListener("canplaythrough", loadHandler, false);
	doneSound.removeEventListener("canplaythrough", loadHandler, false);
        
    //Build the map 
    gameState = BUILD_MAP;
  }
}

function buildMap(levelMap)
{
  for(var row = 0; row < ROWS; row++) 
  {	
    for(var column = 0; column < COLUMNS; column++) 
    { 
      var currentTile = levelMap[row][column];
    
      if(currentTile != EMPTY)
      {
        //Find the tile's x and y position on the tile sheet
        var tilesheetX = Math.floor((currentTile - 1) % tilesheetColumns) * SIZE; 
        var tilesheetY = Math.floor((currentTile - 1) / tilesheetColumns) * SIZE;
        
        switch (currentTile)
        {
          case CAT:
            cat = Object.create(heroObject);
            cat.sourceX = tilesheetX;
            cat.sourceY = tilesheetY;
            cat.x = column * SIZE;
            cat.y = row * SIZE;
			cat.vx=0;
		    cat.vy=0;
			cat.accelerationX=0;
		    cat.accelerationY=0;
			cat.gravityX=0;
			cat.gravityY=0;
			cat.state=cat.UP;	
            sprites.push(cat);
			console.log("CAT");
            break;
            
          case HEDGEHOG:
            var hedgehog = Object.create(hedgehogObject);
            hedgehog.sourceX = tilesheetX;
            hedgehog.sourceY = tilesheetY;            
            hedgehog.x = column * SIZE;
            hedgehog.y = row * SIZE;
            sprites.push(hedgehog);
            hedgehogs.push(hedgehog);
			//distance difference to middle point
  			dx=hedgehog.centerX()-mx;
  			dy=hedgehog.centerY()-my; 
			//Update hedgehog state depending on screen position (dx and dy)
			   if(dy<0 && dy*dy>dx*dx){
			  	hedgehog.state=hedgehog.UP;
				hedgehog.vx = hedgehog.speed;
			  }
			  if(dx>0 && dx*dx>dy*dy){
			  	hedgehog.state=hedgehog.RIGHT;
				hedgehog.vy = hedgehog.speed;
			  }
			   if(dy>0 && dy*dy>dx*dx){
			 	hedgehog.state=hedgehog.DOWN;
				hedgehog.vx = hedgehog.speed;
			  }
			    if(dx<0 && dx*dx>dy*dy){
			  	hedgehog.state=hedgehog.LEFT;
			    hedgehog.vy = hedgehog.speed;
			  }	
			hedgehog.update();
            break;
          
		  	case 2:
		  	case 3:
			case 4:
			case 5:
			case 6:
			//case BOX:
			map[row][column]=BOX;
            var box = Object.create(spriteObject);
            box.sourceX = tilesheetX;
            box.sourceY = tilesheetY;
            box.x = column * SIZE;
            box.y = row * SIZE;
            sprites.push(box);
            boxes.push(box);
            break;
				
          case CRYSTAL:
            var crystal = Object.create(crystalObject);
            crystal.sourceX = tilesheetX;
            crystal.sourceY = tilesheetY;            
            crystal.x = column * SIZE;
            crystal.y = row * SIZE;
            sprites.push(crystal);
            crystals.push(crystal);
			//distance difference to middle point
  			dx=crystal.centerX()-mx;
  			dy=crystal.centerY()-my; 
			//Update crystal state depending on screen position (dx and dy)
			  if(dy<0 && dy*dy>dx*dx){
			  	crystal.state=crystal.UP;
			  }
			  if(dx>0 && dx*dx>dy*dy){
			  	crystal.state=crystal.RIGHT;
			  }
			   if(dy>0 && dy*dy>dx*dx){
				crystal.state=crystal.DOWN;
			  }
			  if(dx<0 && dx*dx>dy*dy){
				crystal.state=crystal.LEFT;
			  }	
			crystal.update();
			break;
				
          case DOOR:
            door = Object.create(spriteObject);
            door.sourceX = tilesheetX;
            door.sourceY = tilesheetY;
            door.x = column * SIZE;
            door.y = row * SIZE;
            sprites.push(door);
            break; 
            
          default:
            var sprite = Object.create(spriteObject);
            sprite.sourceX = tilesheetX;
            sprite.sourceY = tilesheetY;
            sprite.x = column * SIZE;
            sprite.y = row * SIZE;
            sprites.push(sprite);       
        }
      }
    }
  }
}

function createOtherObjects()
{
  
  gameMessage = Object.create(messageObject);
  gameMessage.x = 230;
  gameMessage.y = 200;
  gameMessage.font = "bold 30px Helvetica";
  gameMessage.fillStyle = "white";
  gameMessage.text = "Hej";
  gameMessage.visible = false;
  messages.push(gameMessage);
}

function playGame()
{ 
  //Show title
  if(keyPressed==false){
	gameMessage.x = 130;
  	gameMessage.y = 410;
  	gameMessage.font = "bold 100px Helvetica";
  	gameMessage.text = "moon";
  	gameMessage.visible = true;
  } else {
	gameMessage.x = 230;
  	gameMessage.y = 200;
  	gameMessage.font = "bold 30px Helvetica";
  	gameMessage.visible = false;
  }
	
  //--- The cat 

  // Up	state
  if(cat.state==cat.UP && cat.isOnGround){
	  //Left
	  if(moveLeft && !moveRight)
	  {
	    cat.accelerationX = -cat.speed;
	    cat.friction = 1;
	  }
	  //Right
	  if(moveRight && !moveLeft)
	  {
	    cat.accelerationX = cat.speed;
	    cat.friction = 1;
	  }
	  //Jump
	  if(moveUp && !moveDown)
	  {
	    cat.vy =- cat.jumpForce;
	    cat.isOnGround = false;
	    cat.friction = 1;
		//Play the jump sound
  		jumpSound.currentTime = 0;
  		jumpSound.play();
	  }
  }
  
  // Right state
  if(cat.state==cat.RIGHT && cat.isOnGround){
	  //Down
	  if(moveDown && !moveUp)
	  {
	    cat.accelerationY = cat.speed;
	    cat.friction = 1;
	  }
	  //Up
	  if(moveUp && !moveDown)
	  {
	    cat.accelerationY = -cat.speed;
	    cat.friction = 1;
	  }
	  //Jump
	  if(moveRight && !moveLeft)
	  {
	    cat.vx =+ cat.jumpForce;
	    cat.isOnGround = false;
	    cat.friction = 1;
		//Play the jump sound
  		jumpSound.currentTime = 0;
  		jumpSound.play();
	  }
  }

  // Down state
  if(cat.state==cat.DOWN && cat.isOnGround){
	  if(moveLeft && !moveRight)
	  {
	    cat.accelerationX = -cat.speed;
	    cat.friction = 1;
	  }
	  //Right
	  if(moveRight && !moveLeft)
	  {
	    cat.accelerationX = cat.speed;
	    cat.friction = 1;
	  }
	  //Jump
	  if(moveDown && !moveUp)
	  {
	    cat.vy =+ cat.jumpForce;
	    cat.isOnGround = false;
	    cat.friction = 1;
		//Play the jump sound
  		jumpSound.currentTime = 0;
  		jumpSound.play();
	  }
  }
  
  // Left state
  if(cat.state==cat.LEFT && cat.isOnGround){
	  //Down
	  if(moveDown && !moveUp)
	  {
	    cat.accelerationY = cat.speed;
	    cat.friction = 1;
	  }
	  //Up
	  if(moveUp && !moveDown)
	  {
	    cat.accelerationY = -cat.speed;
	    cat.friction = 1;
	  }
	  //Jump
	  if(moveLeft && !moveRight)
	  {
	    cat.vx =- cat.jumpForce;
	    cat.isOnGround = false;
	    cat.friction = 1;
		//Play the jump sound
  		jumpSound.currentTime = 0;
  		jumpSound.play();
	  }
  }
  //distance difference to middle point
  dx=cat.centerX()-mx;
  dy=cat.centerY()-my; 
  
   //update cat state and gravity
   if(dy<0 && dy*dy>dx*dx){
  	cat.state=cat.UP;
	cat.update();
	cat.gravityX=0;
	cat.gravityY=G; 
  	cat.vy += cat.gravityY;
  }
  if(dx>0 && dx*dx>dy*dy){
  	cat.state=cat.RIGHT;
	cat.update();
	cat.gravityX=-G;
	cat.gravityY=0;
	cat.vx += cat.gravityX;
  }
   if(dy>0 && dy*dy>dx*dx){
  	cat.state=cat.DOWN;
	cat.update();
	cat.gravityX=0;
	cat.gravityY=-G;
  	cat.vy += cat.gravityY;
  }
    if(dx<0 && dx*dx>dy*dy){
  	cat.state=cat.LEFT;
	cat.update();
	cat.gravityX=G;
	cat.gravityY=0;
	cat.vx += cat.gravityX;
  }	
  
  //Set the cat's acceleration, friction and gravity 
  //to zero if none of the arrow keys are being pressed
  if(!moveLeft && !moveRight && !moveUp && !moveDown)
  { 
    cat.friction = 0.8; 
	cat.accelerationX=0;
	cat.accelerationY=0;
  }

  //Apply the acceleration
  cat.vx += cat.accelerationX; 
  cat.vy += cat.accelerationY;
  
  //Apply friction or turn off acceleration
  if(cat.isOnGround){
	  cat.vx *= cat.friction; 
	  cat.vy *= cat.friction;
  } else {
  	cat.accelerationX=0;
	cat.accelerationY=0;
  }
 
  //Gravity
//  cat.vx += cat.gravityX;
//  cat.vy += cat.gravityY;
	
	
  //Limit the speed
  //Don't limit the upward speed because it will choke the jump effect
  
  if (cat.vx > cat.speedLimit)
  {
    cat.vx = cat.speedLimit;
  }
  if (cat.vx < -cat.speedLimit)
  {
    cat.vx = -cat.speedLimit;
  } 
  if (cat.vy > cat.speedLimit)
  {
    cat.vy = cat.speedLimit;
  } 
  if (cat.vy < -cat.speedLimit)
  {
    cat.vy = -cat.speedLimit;
  } 
  
  //Move the cat and set its screen boundaries
  cat.x = Math.max(0, Math.min(cat.x + cat.vx, gameWorld.width - cat.width - 0)); 
  cat.y = Math.max(0, Math.min(cat.y + cat.vy, gameWorld.height - cat.height - 0));
  
  //Check for a collision between the cat and the boxes
  for(var i = 0; i < boxes.length; i++)
  { 	  
    var collisionSide = blockRectangle(cat, boxes[i], false);
	  
	//Cat up 
	if (cat.state==cat.UP){		 
		if(collisionSide === "bottom" && cat.vy >= 0)
	    {
	      cat.isOnGround = true;
	      cat.vy = -cat.gravityY;
	    }
	    else if(collisionSide === "top" && cat.vy <= 0)
	    {
	      cat.vy = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 			
	    }
	    else if(collisionSide === "right" && cat.vx >= 0)
	    {
	      cat.vx = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    else if(collisionSide === "left" && cat.vx <= 0)
	    {
	      cat.vx = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    if(collisionSide == "none" && cat.vy >= 0)
	    {
	      cat.isOnGround = false;
	    }  
	}
	
    //Cat right 
	if (cat.state==cat.RIGHT){	
		if(collisionSide === "left" && cat.vx <= 0)
	    {
	      cat.isOnGround = true;
	      cat.vx = -cat.gravityX;
	    }
	    else if(collisionSide === "right" && cat.vx >= 0)
	    {
	      cat.vx = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    else if(collisionSide === "top" && cat.vy <= 0)
	    {
	      cat.vy = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    else if(collisionSide === "bottom" && cat.vy >= 0)
	    {
	      cat.vy = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    if(collisionSide == "none" && cat.vx <= 0)
	    {
	      cat.isOnGround = false;
	    } 
	}
	
    //Cat down 
	if (cat.state==cat.DOWN){		 
		if(collisionSide === "top" && cat.vy <= 0)
	    {
	      cat.isOnGround = true;
	      cat.vy = -cat.gravityY;
	    }
	    else if(collisionSide === "bottom" && cat.vy >= 0)
	    {
	      cat.vy = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    else if(collisionSide === "right" && cat.vx >= 0)
	    {
	      cat.vx = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    else if(collisionSide === "left" && cat.vx <= 0)
	    {
	      cat.vx = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    if(collisionSide == "none" && cat.vy <= 0)
	    {
	      cat.isOnGround = false;
	    }  
	}
	
   //Cat left
	if (cat.state==cat.LEFT){	
		if(collisionSide === "right" && cat.vx >= 0)
	    {
	      cat.isOnGround = true;
	      cat.vx = -cat.gravityX;
	    }
	    else if(collisionSide === "left" && cat.vx <= 0)
	    {
	      cat.vx = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    else if(collisionSide === "top" && cat.vy <= 0)
	    {
	      cat.vy = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    else if(collisionSide === "bottom" && cat.vy >= 0)
	    {
	      cat.vy = 0;
		  //Play the land sound
		  landSound.currentTime = 0;
		  landSound.play(); 
	    }
	    if(collisionSide == "none" && cat.vx >= 0)
	    {
	      cat.isOnGround = false;
	    } 
	}	

  }
  
  //-- The heddgehogs
  for(var i = 0; i < hedgehogs.length; i++)
  {
    var hedgehog = hedgehogs[i];
    
    //Move the hedgehog if its state is NORMAL
    if(hedgehog.state !== hedgehog.SQUASHED)
    {
      hedgehog.x += hedgehog.vx;
      hedgehog.y += hedgehog.vy;
    }
    
    //Check whether the hedgehog is at a cell corner
    if(Math.floor(hedgehog.x) % SIZE === 0
    && Math.floor(hedgehog.y) % SIZE === 0)
    {
      //Change the hedgehog's direction if there's no BOX under it
      
      //Find the hedgehog's column and row in the array
	  var hedgehogColumn = Math.floor(hedgehog.x / SIZE);
	  var hedgehogRow = Math.floor(hedgehog.y / SIZE);
		
	  //hedgehog UP	
	  if(hedgehog.state==hedgehog.UP){	
		  if(hedgehogRow < ROWS - 1)
		  { 
		    var thingBelowLeft = map[hedgehogRow + 1][hedgehogColumn - 1];
		    var thingBelowRight = map[hedgehogRow + 1][hedgehogColumn + 1];
			    
	        if(thingBelowLeft !== BOX || thingBelowRight !== BOX)
	        {
	          hedgehog.vx *= -1;
	        }
	      }
			  
	      if(hedgehogColumn > 0)
	      {
	        var thingToTheLeft = map[hedgehogRow][hedgehogColumn - 1];
	        if(thingToTheLeft === BOX)
	        {
	          hedgehog.vx *= -1;
	        }
	      } 
			  
	      if(hedgehogColumn < COLUMNS - 1)
	      {
	        var thingToTheRight = map[hedgehogRow][hedgehogColumn + 1];
	        if(thingToTheRight === BOX)
	        {
	          hedgehog.vx *= -1;
	        }
	      } 
	  }
	  
  	  //hedgehog RIGHT	
	  if(hedgehog.state==hedgehog.RIGHT){	
		  if(hedgehogColumn < COLUMNS - 1)
		  { 
		    var thingLeftUp = map[hedgehogRow - 1][hedgehogColumn - 1];
		    var thingLeftDown = map[hedgehogRow + 1][hedgehogColumn - 1];
			    
	        if(thingLeftUp !== BOX || thingLeftDown !== BOX)
	        {
	          hedgehog.vy *= -1;
	        }
	      }
			  
	      if(hedgehogRow > 0)
	      {
	        var thingAbove = map[hedgehogRow-1][hedgehogColumn];
	        if(thingAbove === BOX)
	        {
	          hedgehog.vy *= -1;
	        }
	      } 
			  
	      if(hedgehogColumn < ROWS - 1)
	      {
	        var thingBelow = map[hedgehogRow+1][hedgehogColumn];
	        if(thingBelow === BOX)
	        {
	          hedgehog.vy *= -1;
	        }
	      } 
	  }	  

	  //hedgehog DOWN	
	  if(hedgehog.state==hedgehog.DOWN){	
		  if(hedgehogRow > 0)
		  { 
		    var thingAboveLeft = map[hedgehogRow - 1][hedgehogColumn - 1];
		    var thingAboveRight = map[hedgehogRow - 1][hedgehogColumn + 1];
			    
	        if(thingAboveLeft !== BOX || thingAboveRight !== BOX)
	        {
	          hedgehog.vx *= -1;
	        }
	      }
			  
	      if(hedgehogColumn > 0)
	      {
	        var thingToTheLeft = map[hedgehogRow][hedgehogColumn - 1];
	        if(thingToTheLeft === BOX)
	        {
	          hedgehog.vx *= -1;
	        }
	      } 
			  
	      if(hedgehogColumn < COLUMNS - 1)
	      {
	        var thingToTheRight = map[hedgehogRow][hedgehogColumn + 1];
	        if(thingToTheRight === BOX)
	        {
	          hedgehog.vx *= -1;
	        }
	      } 
	  }
	  
	  //hedgehog LEFT	
	  if(hedgehog.state==hedgehog.LEFT){	
		  if(hedgehogColumn > 0)
		  { 
		    var thingRightUp = map[hedgehogRow - 1][hedgehogColumn + 1];
		    var thingRightDown = map[hedgehogRow + 1][hedgehogColumn + 1];
			    
	        if(thingRightUp !== BOX || thingRightDown !== BOX)
	        {
	          hedgehog.vy *= -1;
	        }
	      }
			  
	      if(hedgehogRow > 0)
	      {
	        var thingAbove = map[hedgehogRow-1][hedgehogColumn];
	        if(thingAbove === BOX)
	        {
	          hedgehog.vy *= -1;
	        }
	      } 
			  
	      if(hedgehogColumn < ROWS - 1)
	      {
	        var thingBelow = map[hedgehogRow+1][hedgehogColumn];
	        if(thingBelow === BOX)
	        {
	          hedgehog.vy *= -1;
	        }
	      } 
	  }	   
    }
  }
  
  //Collision between the cat and the hedgehogs
  for(var i = 0; i < hedgehogs.length; i++)
  {
    var hedgehog = hedgehogs[i];
    
    if(hedgehog.visible && hitTestCircle(cat, hedgehog) && hedgehog.state !== hedgehog.SQUASHED)
    {
      if(hedgehog.state == hedgehog.UP && cat.vy > 0)
      {
        blockCircle(cat, hedgehog, true);
        squashHedgehog(hedgehog);
		//Play the squash sound
  		squashSound.currentTime = 0;
  		squashSound.play();
      } else if(hedgehog.state == hedgehog.RIGHT && cat.vx < 0){
		blockCircle(cat, hedgehog, true);
        squashHedgehog(hedgehog);
		//Play the squash sound
  		squashSound.currentTime = 0;
  		squashSound.play();
	  } else if(hedgehog.state == hedgehog.DOWN && cat.vy < 0){
		blockCircle(cat, hedgehog, true);
        squashHedgehog(hedgehog);  
		//Play the squash sound
  		squashSound.currentTime = 0;
  		squashSound.play();
	  } else if(hedgehog.state == hedgehog.LEFT && cat.vx > 0){
		blockCircle(cat, hedgehog, true);
        squashHedgehog(hedgehog); 
		//Play the squash sound
  		squashSound.currentTime = 0;
  		squashSound.play();
	  }
      else
      {
        gameState = OVER;
		//Play the dead sound
  	 	deadSound.currentTime = 0;
  	 	deadSound.play();
      }
    }
  }
  
  //Hedgehog explosion 
  for(var i = 0; i < hedgehogs.length; i++)
  {
    var hedgehog = hedgehogs[i];
    
    if(hedgehog.visible && hedgehog.state == hedgehog.SQUASHED){
	  squashCounter++;
	  switch (squashCounter){
	  	case 10:
		    hedgehog.sourceX = SIZE*1;
	  break;

	  case 20:
		    hedgehog.sourceX = SIZE*2;
	  break;

	  case 30:
		    hedgehog.sourceX = SIZE*3;
	  break;
		  
	  case 40:
		    hedgehog.sourceX = SIZE*4;
	  break;
		  
	  case 50:
		    hedgehog.sourceX = SIZE*5;
	  break;	
	  }  
	}	  
  }

  
  //Collision between the cat and the crystals
  for(var i = 0; i < crystals.length; i++)
  {
    var crystal = crystals[i];
    
    if(crystal.visible && hitTestCircle(cat, crystal)){
		crystal.visible=false;
		crystalsCollected++;
		//Play the crystal sound
  		crystalSound.currentTime = 0;
  		crystalSound.play();
	}
  }
  
  //Collision between the cat and the door
  if(hitTestRectangle(cat, door))
  {
    //Check if all the crystals have been collected
    if(crystalsCollected === crystals.length)
    {
		if(levelCounter < levelMaps.length)
    	{
	        gameState = LEVEL_COMPLETE;
			//Play the levelUp sound
			levelUpSound.currentTime = 0;
			levelUpSound.play();
		} else {
			gameState = OVER;
			//Play the done sound
			doneSound.currentTime = 0;
			doneSound.play();
		}
    }  
  }
  
  //Scroll the camera
  if(cat.x < camera.leftInnerBoundary())
  {
    camera.x = Math.floor(cat.x - (camera.width / 4));
  }
  if(cat.y < camera.topInnerBoundary())
  {
    camera.y = Math.floor(cat.y - (camera.height / 4));
  }
  if(cat.x + cat.width > camera.rightInnerBoundary())
  {
    camera.x = Math.floor(cat.x + cat.width - (camera.width / 4 * 3));
  }
  if(cat.y + cat.height > camera.bottomInnerBoundary())
  {
    camera.y = Math.floor(cat.y + cat.height - (camera.height / 4 * 3));
  }
  
  //The camera's gameWorld boundaries
  if(camera.x < gameWorld.x)
  {
    camera.x = gameWorld.x;
  }
  if(camera.y < gameWorld.y)
  {
    camera.y = gameWorld.y;
  }
  if(camera.x + camera.width > gameWorld.x + gameWorld.width)
  {
    camera.x = gameWorld.x + gameWorld.width - camera.width;
  }
  if(camera.y + camera.height > gameWorld.height)
  {
    camera.y = gameWorld.height - camera.height;
  } 
}


function squashHedgehog(hedgehog)
{
  //Change the hedgehog's state and update the object 
  hedgehog.state = hedgehog.SQUASHED;
  hedgehog.update(); 
  squashCounter++;
  
  //Remove the hedgehog after 1 second
  setTimeout(removeHedgehog, 1000);
  
  function removeHedgehog()
  {
    hedgehog.visible = false;
	squashCounter=0;
  }
}

function endGame()
{
  //gameOverDisplay.visible = true;
  gameMessage.visible = true;
    
  if(crystalsCollected === crystals.length)
  {
    gameMessage.text = "Master!";
  }
  else
  {
     gameMessage.text = "Shoot...";
  }
}

//https://blog.andrewray.me/how-to-clone-a-nested-array-in-javascript/
function arrayClone( arr ) {

    var i, copy;

    if( Array.isArray( arr ) ) {
        copy = arr.slice( 0 );
        for( i = 0; i < copy.length; i++ ) {
            copy[ i ] = arrayClone( copy[ i ] );
        }
        return copy;
    } else if( typeof arr === 'object' ) {
        throw 'Cannot clone array containing an object!';
    } else {
        return arr;
    }

}

function render()
{ 
  drawingSurface.clearRect(0, 0, canvas.width, canvas.height);

  //Position the gameWorld inside the camera
  drawingSurface.save();
  drawingSurface.translate(-camera.x, -camera.y);
  
  //Display the sprites
  if(sprites.length !== 0)
  {
    for(var i = 0; i < sprites.length; i++)
    {
      var sprite = sprites[i];
      if(sprite.visible && sprite.x>camera.x-SIZE && sprite.x<camera.x+canvas.width && sprite.y>camera.y-SIZE && sprite.y<camera.y+canvas.height )
      {
        drawingSurface.drawImage
        (
          image, 
          sprite.sourceX, sprite.sourceY, 
          sprite.sourceWidth, sprite.sourceHeight,
          Math.floor(sprite.x), Math.floor(sprite.y), 
          sprite.width, sprite.height
        ); 
      }
    }
  }
  
  drawingSurface.restore();
  
  //Display the game messages
  if(messages.length !== 0)
  {
    for(var i = 0; i < messages.length; i++)
    {
       var message = messages[i];
       if(message.visible)
       {
         drawingSurface.font = message.font;  
         drawingSurface.fillStyle = message.fillStyle;
         drawingSurface.textBaseline = message.textBaseline;
	     drawingSurface.fillText(message.text, message.x, message.y);  
	   }
	}
  }
}

}());
